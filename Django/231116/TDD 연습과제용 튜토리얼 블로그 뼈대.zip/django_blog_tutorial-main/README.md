# django_blog_tutorial
* 장고로 만드는 블로그 튜토리얼
* 노션 링크 : https://paullabworkspace.notion.site/django-blog-1cc76dd8dc4444d1b2b7bb5f8f162291?pvs=4
